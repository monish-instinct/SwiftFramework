// swift-tools-version:5.7
import PackageDescription

let package = Package(
    name: "ClPackageTest",
    platforms: [
        .macOS(.v13)  // macOS 13 and above
    ],
    products: [
        .library(
            name: "ClPackageTest",
            targets: ["ClPackageTest"]
        ),
    ],
    dependencies: [
        .package(url: "https://github.com/stoneburner/SQLCipher", from: "0.0.4")
    ],
    targets: [
        .target(
            name: "ClPackageTest",
            dependencies: ["SQLCipher"]  // Link SQLCipher as a dependency
        ),
        .testTarget(
            name: "ClPackageTestTests",
            dependencies: ["ClPackageTest"]
        ),
    ]
)
